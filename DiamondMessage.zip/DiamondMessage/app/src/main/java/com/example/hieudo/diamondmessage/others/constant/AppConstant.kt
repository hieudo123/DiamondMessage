package com.example.hieudo.diamondmessage.others.constant

class AppConstant {
    companion object{
        const val PREF_USER: String = "pref_user"
        const val QB_DATE_SENT: String = "date_sent"
        const val EMAIL: String = "email"
        const val PASSWORD = "passowrd"
        const val APPLICATION_ID = "80138"
        const val AUTH_KEY = "sG4Zsym6nLmBPHO"
        const val AUTH_SECRET = "7d8NK-9reaVnmbt"
        const val ACCOUNT_KEY = "XBnWKn771jouJCyiVH6T"
        const val EXTRA_LOGIN_RESULT_CODE = 1002
        const val ITEM_SEND_MESSAGE_TYPE: Int = 0
        const val ITEM_RECEIVE_MESSAGE_TYPE : Int = 1
    }
}