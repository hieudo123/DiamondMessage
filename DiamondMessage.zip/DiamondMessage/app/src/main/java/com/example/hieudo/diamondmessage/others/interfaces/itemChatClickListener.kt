package com.example.hieudo.diamondmessage.others.interfaces

import com.quickblox.chat.model.QBChatDialog

interface itemChatClickListener {
    fun onItemClickListener(qbChatDialog: QBChatDialog)
}