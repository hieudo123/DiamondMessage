package com.example.hieudo.diamondmessage.data.models

data class UserModel(var id :Int,
                     var email: String,
                     var password :String,
                     var fullname :String) {
}