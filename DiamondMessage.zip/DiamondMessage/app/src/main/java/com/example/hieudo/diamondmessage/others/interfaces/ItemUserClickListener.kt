package com.example.hieudo.diamondmessage.others.interfaces

import com.quickblox.users.model.QBUser

interface ItemUserClickListener {
    fun onItemClickListener(qbUser: QBUser)
}