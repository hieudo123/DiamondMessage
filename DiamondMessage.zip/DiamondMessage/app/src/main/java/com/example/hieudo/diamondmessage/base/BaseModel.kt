package com.example.hieudo.diamondmessage.base

import android.os.Parcelable
import java.io.Serializable

class BaseModel : Serializable {
}